from pathlib import Path
import json
import numpy as np
import nibabel as nib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
w=Path(__file__).parent/'output';p=w/'preproc';r=w/'roi';out=w/'qc'
t=nib.load(__import__('os').environ['T'])
tc=nib.as_closest_canonical(t).get_fdata();bc=nib.as_closest_canonical(nib.load(p/'dwi_to_T1_Warped.nii.gz')).get_fdata()
fig,ax=plt.subplots(2,5,figsize=(14,6))
for c,frac in enumerate([.25,.35,.45,.55,.65]):
 z=round(frac*(tc.shape[2]-1))
 for rr,a in enumerate([tc,bc]):
  ax[rr,c].imshow(a[:,:,z].T,origin='lower',cmap='gray',vmin=0,vmax=np.percentile(a[a>0],99));ax[rr,c].axis('off');ax[rr,c].set_title(('T1' if rr==0 else 'Registered b0')+' z='+str(z))
fig.tight_layout();fig.savefig(out/'DWI_T1_alignment.png',dpi=130)
mask=nib.load(p/'b0_brain_mask.nii.gz').get_fdata()>0;report={}
for f in r.glob('*_DWI.nii.gz'):
 im=nib.load(f);m=im.get_fdata()>0;report[f.name]={'voxels':int(m.sum()),'inside_brain_fraction':float(mask[m].mean()) if m.any() else 0}
g=np.loadtxt(p/'dwi_eddy.eddy_rotated_bvecs');v=np.loadtxt(p/'gradcheck.bvec');report['gradient_check']={'max_absolute_component_difference':float(np.max(np.abs(g-v)))}
(out/'model_qc.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
# Direction-encoded color map; absolute world-vector components, no reorientation of vector values.
fa=nib.as_closest_canonical(nib.load(p/'fa.nii.gz')).get_fdata();ve=nib.as_closest_canonical(nib.load(p/'principal_direction.nii.gz')).get_fdata();rgb=np.clip(np.abs(ve)*fa[...,None]*1.8,0,1)
fig,ax=plt.subplots(1,5,figsize=(14,3))
for c,frac in enumerate([.2,.35,.5,.65,.8]):
 z=round(frac*(fa.shape[2]-1));ax[c].imshow(rgb[:,:,z,:].transpose(1,0,2),origin='lower');ax[c].axis('off');ax[c].set_title('DEC FA z='+str(z))
fig.tight_layout();fig.savefig(out/'DEC_FA.png',dpi=130)
