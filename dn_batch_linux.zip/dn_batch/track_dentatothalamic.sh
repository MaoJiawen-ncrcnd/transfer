#!/usr/bin/env bash
set -euo pipefail
export MRTRIX_RNG_SEED=20261027
P="$W/output/preproc";R="$W/output/roi";mkdir -p "$W/output/tracts";cd "$W/output/tracts"
exec > >(tee -a tracking.log) 2>&1
date -Is
for side in Left Right; do
 if [ "$side" = Left ]; then contra=Right; else contra=Left; fi
 name="${contra}Dentate_to_${side}MorelVLp"
 tckgen "$P/wm_fod.mif" "${name}_candidate.tck" -algorithm iFOD2 -seed_image "$R/${side}_Morel_VLp_DWI.nii.gz" -seed_unidirectional -include "$R/${contra}_Dentate_DWI.nii.gz" -stop -exclude "$R/${contra}_ThalamusUnion_DWI.nii.gz" -exclude "$R/${side}_CerebellarCortex_DWI.nii.gz" -mask "$P/b0_brain_mask.nii.gz" -step 1 -angle 45 -minlength 20 -maxlength 200 -cutoff 0.05 -select 2000 -seeds 2000000 -nthreads 3
 tckinfo "${name}_candidate.tck" -count
done
date -Is
echo TRACKING_COMPLETE
