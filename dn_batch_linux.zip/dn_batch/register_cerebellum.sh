#!/usr/bin/env bash
set -euo pipefail
export ITK_GLOBAL_DEFAULT_NUMBER_OF_THREADS=2
cd "$W/output/roi"
exec > >(tee -a cerebellum_registration.log) 2>&1
date -Is
antsRegistrationSyN.sh -d 3 -f "$T" -m $FSLDIR/data/standard/MNI152_T1_1mm.nii.gz -o fslMNI_to_T1_ -t s -n 2
antsApplyTransforms -d 3 -i "$A/reference_atl-Anatom_space-MNI_dseg.nii" -r "$T" -o CerebellumLabels_T1.nii.gz -n NearestNeighbor -t fslMNI_to_T1_1Warp.nii.gz -t fslMNI_to_T1_0GenericAffine.mat
date -Is
echo CEREBELLUM_REGISTRATION_COMPLETE
