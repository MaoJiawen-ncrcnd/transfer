#!/usr/bin/env bash
set -euo pipefail
export ITK_GLOBAL_DEFAULT_NUMBER_OF_THREADS=4
cd "$W/output/roi"
exec > >(tee -a morel_registration.log) 2>&1
date -Is
antsRegistrationSyN.sh -d 3 -f "$T" -m "$M" -o morel_to_T1_ -t s -n 4
for side in Left Right; do
 antsApplyTransforms -d 3 -i "${side}_Morel_VLpd_VLpv_MNI.nii.gz" -r "$T" -o "${side}_Morel_VLp_T1.nii.gz" -n NearestNeighbor -t morel_to_T1_1Warp.nii.gz -t morel_to_T1_0GenericAffine.mat
done
date -Is
echo MOREL_REGISTRATION_COMPLETE
