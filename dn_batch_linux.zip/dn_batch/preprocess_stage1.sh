#!/usr/bin/env bash
set -euo pipefail
export FSLOUTPUTTYPE=NIFTI_GZ
export OMP_NUM_THREADS=4
export ITK_GLOBAL_DEFAULT_NUMBER_OF_THREADS=4
mkdir -p "$W/output/preproc"
cd "$W/output/preproc"
exec > >(tee -a stage1.log) 2>&1
date -Is
D="${S}/dwi/${ID}_acq-dki_dir-AP_dwi"
if [ ! -f dwi_denoised.mif ]; then
 mrconvert "$D.nii.gz" dwi_raw.mif -fslgrad "$D.bvec" "$D.bval" -json_import "$D.json" -nthreads 4
 dwidenoise dwi_raw.mif dwi_denoised.mif -noise noise.mif -nthreads 4
 mrconvert dwi_denoised.mif dwi_denoised.nii.gz -export_grad_fsl bvecs bvals -nthreads 4
fi
# Partial Fourier 6/8: standard mrdegibbs is deferred pending validation.
if [ ! -f topup_corrected.nii.gz ]; then
 fslmerge -t ap_pa "$W/output/qc/first_b0.nii.gz" "${S}/fmap/${ID}_acq-dki_dir-PA_epi.nii.gz"
 cp "$W/acqparams.txt" acqparams.txt
 topup --imain=ap_pa --datain=acqparams.txt --config=b02b0.cnf --out=topup --iout=topup_corrected --fout=field_hz --verbose
fi
fslmaths topup_corrected -Tmean b0_corrected_mean
bet b0_corrected_mean b0_brain -m -f 0.25
date -Is
echo STAGE1_COMPLETE
