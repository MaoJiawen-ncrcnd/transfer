from pathlib import Path
import json
import numpy as np
import nibabel as nib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Line3DCollection
w=Path(__file__).parent/'output';out=w/'tracts';ref=nib.load(w/'preproc/corrected_b0.nii.gz')
def resample(s):
 d=np.r_[0,np.cumsum(np.linalg.norm(np.diff(s,axis=0),axis=1))];keep=np.r_[True,np.diff(d)>1e-8];return np.stack([np.interp(np.linspace(0,d[-1],100),d[keep],s[keep,k]) for k in range(3)],1)
report={'method':'Independent Python implementation of iterative along-tract Mahalanobis and length outlier rejection; not identical to Vistasoft','distance_threshold':5,'length_threshold_sd':4,'nodes':100,'max_rounds':5,'bundles':{}}
fig=plt.figure(figsize=(12,6));plotdata=[]
for ii,f in enumerate(sorted(out.glob('*_endpoint_checked.tck'))):
 sls=list(nib.streamlines.load(f).streamlines);ids=np.arange(len(sls));rounds=[]
 for it in range(5):
  if len(ids)<20:break
  x=np.stack([resample(sls[i]) for i in ids]);lengths=np.array([np.linalg.norm(np.diff(sls[i],axis=0),axis=1).sum() for i in ids]);delta=x-x.mean(0);ds=np.empty(x.shape[:2])
  for node in range(100):
   cov=np.cov(x[:,node,:],rowvar=False)+np.eye(3)*1e-6;ds[:,node]=np.sqrt(np.maximum(0,np.einsum('ni,ij,nj->n',delta[:,node],np.linalg.pinv(cov),delta[:,node])))
  good=(ds.max(axis=1)<=5)&(lengths<=lengths.mean()+4*lengths.std(ddof=1));rounds.append({'before':len(ids),'removed':int((~good).sum())});ids=ids[good]
  if good.all():break
 kept=[sls[i] for i in ids];stem=f.name.replace('_endpoint_checked.tck','');tg=nib.streamlines.Tractogram(kept,affine_to_rasmm=np.eye(4));nib.streamlines.save(tg,str(out/(stem+'_cleaned.tck')))
 hdr=nib.streamlines.TrkFile.create_empty_header();hdr['dimensions']=ref.shape[:3];hdr['voxel_sizes']=ref.header.get_zooms()[:3];hdr['voxel_to_rasmm']=ref.affine;hdr['voxel_order']=''.join(nib.aff2axcodes(ref.affine)).encode();nib.streamlines.save(nib.streamlines.TrkFile(tg,header=hdr),str(out/(stem+'_cleaned.trk')))
 np.savetxt(out/(stem+'_cleaned_keep_indices.txt'),ids,fmt='%d')
 report['bundles'][stem]={'input':len(sls),'retained':len(kept),'rounds':rounds}
 color='tab:blue' if stem.startswith('RightDentate') else 'tab:orange';ax=fig.add_subplot(1,2,ii+1,projection='3d')
 if kept:
  sample=kept[::max(1,len(kept)//250)];pts=np.vstack(sample);ax.add_collection3d(Line3DCollection(sample,colors=color,linewidths=.5,alpha=.35));lo=pts.min(0)-5;hi=pts.max(0)+5;ax.set_xlim(lo[0],hi[0]);ax.set_ylim(lo[1],hi[1]);ax.set_zlim(lo[2],hi[2]);ax.set_box_aspect(hi-lo)
 ax.set(xlabel='R (mm)',ylabel='A (mm)',zlabel='S (mm)',title=stem.replace('_',' ')+'\n'+str(len(kept))+' cleaned streamlines');ax.view_init(elev=15,azim=-85);plotdata.append((stem,color,kept))
fig.tight_layout();fig.savefig(out/'cleaned_tract_overview.png',dpi=160);(out/'cleaning_summary.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
