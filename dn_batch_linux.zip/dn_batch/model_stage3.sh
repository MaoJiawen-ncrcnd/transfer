#!/usr/bin/env bash
set -euo pipefail
export FSLOUTPUTTYPE=NIFTI_GZ
export ITK_GLOBAL_DEFAULT_NUMBER_OF_THREADS=3
export OMP_NUM_THREADS=3
cd "$W/output/preproc"
exec > >(tee -a stage3.log) 2>&1
# Explicit completion gate; no modelling of partial EDDY outputs.
if ! grep -q EDDY_COMPLETE stage2.log; then echo 'EDDY is not complete; run again after completion.'; exit 2; fi
python3 "$W/eddy_qc.py"
if [ ! -f dwi_eddy.mif ]; then mrconvert dwi_eddy.nii.gz dwi_eddy.mif -fslgrad dwi_eddy.eddy_rotated_bvecs bvals -nthreads 3; fi
# Installed MRtrix wrapper injects an unsupported -nt into newer ANTs.
# Run the same N4 estimation directly; threading is set via ITK environment.
dwiextract dwi_eddy.mif -bzero - | mrmath - mean n4_input_b0.nii.gz -axis 3
N4BiasFieldCorrection -d 3 -i n4_input_b0.nii.gz -w b0_brain_mask.nii.gz -o '[n4_corrected_b0.nii.gz,n4_bias.nii.gz]' -s 4 -b '[100,3]' -c '[1000,0.0]'
biasmean=$(mrstats n4_bias.nii.gz -mask b0_brain_mask.nii.gz -output mean)
mrcalc n4_bias.nii.gz "$biasmean" -div bias_field.mif
mrcalc dwi_eddy.mif bias_field.mif -div dwi_biascorrected.mif
dwiextract dwi_biascorrected.mif -bzero - | mrmath - mean corrected_b0.nii.gz -axis 3
dwi2response dhollander dwi_biascorrected.mif response_wm.txt response_gm.txt response_csf.txt -mask b0_brain_mask.nii.gz -voxels response_voxels.mif -nthreads 3
dwi2fod msmt_csd dwi_biascorrected.mif response_wm.txt wm_fod.mif response_gm.txt gm.mif response_csf.txt csf.mif -mask b0_brain_mask.nii.gz -nthreads 3
dwi2tensor dwi_biascorrected.mif tensor.mif -mask b0_brain_mask.nii.gz -nthreads 3
tensor2metric tensor.mif -fa fa.nii.gz -adc md.nii.gz -ad ad.nii.gz -rd rd.nii.gz -vector principal_direction.nii.gz -nthreads 3
antsRegistrationSyN.sh -d 3 -f "$T" -m corrected_b0.nii.gz -o dwi_to_T1_ -t r -n 3
echo MODELLING_COMPLETE
