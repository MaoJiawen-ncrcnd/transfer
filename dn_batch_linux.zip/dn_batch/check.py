import os,json
from pathlib import Path
import numpy as np
import nibabel as nib
s=Path(os.environ['S'])
i=s.name
d=s/'dwi'/(i+'_acq-dki_dir-AP_dwi')
p=s/'fmap'/(i+'_acq-dki_dir-PA_epi')
im=nib.load(str(d)+'.nii.gz')
pa=nib.load(str(p)+'.nii.gz')
assert im.ndim==4 and pa.shape in (im.shape[:3],im.shape[:3]+(1,)) and np.allclose(im.affine,pa.affine,atol=.01),'PA grid or volume count'
b=np.loadtxt(str(d)+'.bval')
g=np.loadtxt(str(d)+'.bvec')
assert b.shape==(im.shape[3],) and g.shape==(3,len(b)) and np.isfinite(b).all() and np.isfinite(g).all()
assert (b<50).any() and ((b>800)&(b<1200)).any() and ((b>1800)&(b<2200)).any()
assert np.allclose(np.linalg.norm(g[:,b>=50],axis=0),1,atol=.05)
rows=[]
for f in (d,p):
 m=json.loads(Path(str(f)+'.json').read_text());pe=m['PhaseEncodingDirection'];v=[0]*3;v['ijk'.index(pe[0])]=-1 if pe.endswith('-') else 1
 t=float(m['TotalReadoutTime']);assert np.isfinite(t) and t>0
 rows.append(v+[t])
assert np.array_equal(rows[0][:3],-np.array(rows[1][:3]))
if os.environ['MODE']=='run':
 w=Path(os.environ['W'])
 np.savetxt(w/'acqparams.txt',rows,fmt=['%d','%d','%d','%.9f'])
 np.savetxt(w/'index.txt',np.ones((1,len(b))),fmt='%d')
 nib.save(im.slicer[:,:,:,int(np.where(b<50)[0][0])],w/'output/qc/first_b0.nii.gz')
