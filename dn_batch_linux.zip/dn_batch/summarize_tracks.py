from pathlib import Path
import json,csv
import numpy as np
import nibabel as nib
from scipy.ndimage import map_coordinates
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Line3DCollection
w=Path(__file__).parent/'output';p=w/'preproc';r=w/'roi';out=w/'tracts'
ref=nib.load(p/'corrected_b0.nii.gz');inv=np.linalg.inv(ref.affine)
def vals(points,img):
 xyz=nib.affines.apply_affine(np.linalg.inv(img.affine),points);return map_coordinates(img.get_fdata(),xyz.T,order=0,mode='constant',cval=0)
report={};fig=plt.figure(figsize=(12,6));all_checked=[]
for idx,(side,contra,color) in enumerate([('Left','Right','tab:blue'),('Right','Left','tab:orange')]):
 name=contra+'Dentate_to_'+side+'MorelVLp';f=out/(name+'_candidate.tck');tg=nib.streamlines.load(f);tracks=list(tg.streamlines)
 seed=nib.load(r/(side+'_Morel_VLp_DWI.nii.gz'));target=nib.load(r/(contra+'_Dentate_DWI.nii.gz'));ex=[nib.load(r/(contra+'_ThalamusUnion_DWI.nii.gz')),nib.load(r/(side+'_CerebellarCortex_DWI.nii.gz'))]
 kept=[];lengths=[];rejected={'endpoint':0,'exclusion':0,'length':0}
 for sl in tracks:
  length=float(np.linalg.norm(np.diff(sl,axis=0),axis=1).sum())
  if not (19.5<=length<=200.5):rejected['length']+=1;continue
  a,b=sl[0:1],sl[-1:]
  if vals(a,seed)[0] and vals(b,target)[0]:pass
  elif vals(b,seed)[0] and vals(a,target)[0]:sl=sl[::-1]
  else:rejected['endpoint']+=1;continue
  # Recheck at <=0.25 mm spacing to detect between-vertex crossings.
  dense=[]
  for x,y in zip(sl[:-1],sl[1:]):
   n=max(1,int(np.ceil(np.linalg.norm(y-x)/.25)));dense.extend(x+(y-x)*np.arange(n)[:,None]/n)
  dense=np.vstack([dense,sl[-1:]])
  if any(np.any(vals(dense,e)>0) for e in ex):rejected['exclusion']+=1;continue
  kept.append(sl);lengths.append(length)
 tract=nib.streamlines.Tractogram(kept,affine_to_rasmm=np.eye(4));nib.streamlines.save(tract,str(out/(name+'_endpoint_checked.tck')))
 hdr=nib.streamlines.TrkFile.create_empty_header();hdr['dimensions']=ref.shape[:3];hdr['voxel_sizes']=ref.header.get_zooms()[:3];hdr['voxel_to_rasmm']=ref.affine;hdr['voxel_order']=''.join(nib.aff2axcodes(ref.affine)).encode()
 nib.streamlines.save(nib.streamlines.TrkFile(tract,header=hdr),str(out/(name+'_endpoint_checked.trk')))
 density=np.zeros(ref.shape[:3],np.int32)
 for sl in kept:
  xyz=np.rint(nib.affines.apply_affine(inv,sl)).astype(int);xyz=np.unique(xyz,axis=0);ok=np.all((xyz>=0)&(xyz<np.array(ref.shape[:3])),axis=1);xyz=xyz[ok];np.add.at(density,tuple(xyz.T),1)
 nib.save(nib.Nifti1Image(density,ref.affine),out/(name+'_vertex_density.nii.gz'))
 stats={'candidate_count':len(tracks),'endpoint_and_exclusion_checked_count':len(kept),'rejected':rejected,'length_mm_mean':float(np.mean(lengths)) if lengths else None,'length_mm_range':[float(np.min(lengths)),float(np.max(lengths))] if lengths else None}
 for metric in ['fa','md','ad','rd']:
  im=nib.load(p/(metric+'.nii.gz'));data=im.get_fdata();stats[metric+'_mean_in_vertex_visited_voxels']=float(data[density>0].mean()) if kept else None
 report[name]=stats;all_checked.append((name,color,kept))
 ax=fig.add_subplot(1,2,idx+1,projection='3d')
 if kept:
  sample=kept[::max(1,len(kept)//200)];ax.add_collection3d(Line3DCollection(sample,colors=color,linewidths=.5,alpha=.35));points=np.vstack(sample);low=points.min(0)-5;high=points.max(0)+5;ax.set_xlim(low[0],high[0]);ax.set_ylim(low[1],high[1]);ax.set_zlim(low[2],high[2]);ax.set_box_aspect(high-low)
 ax.set(xlabel='R (mm)',ylabel='A (mm)',zlabel='S (mm)',title=contra+' dentate - '+side+' Morel VLp\n'+str(len(kept))+' checked streamlines');ax.view_init(elev=15,azim=-85)
fig.tight_layout();fig.savefig(out/'tract_overview.png',dpi=160)
(out/'tract_summary.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
from nibabel.processing import resample_to_output
cardinal=resample_to_output(ref,voxel_sizes=(2,2,2),order=1);b0=cardinal.get_fdata();af=cardinal.affine;ni=np.linalg.inv(af)
nonempty=[np.vstack(sls) for _,_,sls in all_checked if sls]
if nonempty:
 points=np.vstack(nonempty);lo,hi=np.percentile(points[:,2],[1,99]);zs=np.linspace(lo,hi,8)
 fig,axs=plt.subplots(2,4,figsize=(14,8))
 for ax,z in zip(axs.flat,zs):
  iz=int(np.clip(round((z-af[2,3])/af[2,2]),0,b0.shape[2]-1));z=af[2,3]+iz*af[2,2]
  ax.imshow(b0[:,:,iz].T,origin='lower',cmap='gray',vmin=0,vmax=np.percentile(b0[b0>0],99),extent=[af[0,3],af[0,3]+af[0,0]*(b0.shape[0]-1),af[1,3],af[1,3]+af[1,1]*(b0.shape[1]-1)])
  for name,color,sls in all_checked:
   if not sls:continue
   pts=np.vstack(sls[::max(1,len(sls)//400)]);pts=pts[abs(pts[:,2]-z)<1.5];ax.scatter(pts[:,0],pts[:,1],s=.4,c=color,alpha=.3)
  ax.set_title('Axial RAS z='+str(round(z,1))+' mm');ax.axis('off')
 fig.suptitle('Streamline vertices within +/-1.5 mm of each b0 slice; blue: right DN-left VLp, orange: left DN-right VLp',fontsize=10);fig.tight_layout();fig.savefig(out/'tract_anatomical_slices.png',dpi=160)
