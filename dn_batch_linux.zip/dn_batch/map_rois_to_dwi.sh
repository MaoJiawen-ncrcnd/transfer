#!/usr/bin/env bash
set -euo pipefail
export ITK_GLOBAL_DEFAULT_NUMBER_OF_THREADS=3
P="$W/output/preproc"
R="$W/output/roi"
cd "$R"
exec > >(tee -a map_rois.log) 2>&1
test -f "$P/dwi_to_T1_0GenericAffine.mat"
for side in Left Right; do
 antsApplyTransforms -d 3 -i "${side}_ThalamusUnion_MNI.nii.gz" -r "$T" -o "${side}_ThalamusUnion_T1.nii.gz" -n NearestNeighbor -t morel_to_T1_1Warp.nii.gz -t morel_to_T1_0GenericAffine.mat
 for region in ThalamusUnion CerebellarCortex; do
  maskfilter "${side}_${region}_T1.nii.gz" dilate "${side}_${region}_dil1mm_T1.nii.gz" -npass 1
 done
 for region in Morel_VLp Dentate ThalamusUnion CerebellarCortex; do
  antsApplyTransforms -d 3 -i "${side}_${region}_dil1mm_T1.nii.gz" -r "$P/corrected_b0.nii.gz" -o "${side}_${region}_DWI.nii.gz" -n NearestNeighbor -t "[$P/dwi_to_T1_0GenericAffine.mat,1]"
 done
done
cd "$P"
dwigradcheck dwi_biascorrected.mif -mask b0_brain_mask.nii.gz -number 1000 -export_grad_fsl gradcheck.bvec gradcheck.bval -nthreads 3
echo ROI_MAPPING_COMPLETE
python3 "$W/model_qc.py"
