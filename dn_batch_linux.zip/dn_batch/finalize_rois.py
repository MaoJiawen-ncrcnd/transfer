from pathlib import Path
import json
import numpy as np
import nibabel as nib
from scipy.ndimage import binary_dilation,generate_binary_structure
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
base=Path(__file__).parent/'output';p=base/'roi'
s=Path(__import__('os').environ['ANAT'])
t=nib.load(__import__('os').environ['T']);lab=nib.load(p/'CerebellumLabels_T1.nii.gz').get_fdata();gm=nib.load(__import__('os').environ['GM']);assert gm.shape==t.shape and np.allclose(gm.affine,t.affine)
gm=gm.get_fdata();r={}; masks=[]
for side,dl,cl in [('Left',29,[1,3,5,8,11,14,17,20,23,26]),('Right',30,[2,4,7,10,13,16,19,22,25,28])]:
 for name,m in [('Dentate',lab==dl),('CerebellarCortex',np.isin(lab,cl)&(gm>.5)),('Morel_VLp',nib.load(p/(side+'_Morel_VLp_T1.nii.gz')).get_fdata()>0)]:
  stem=side+'_'+name; nib.save(nib.Nifti1Image(m.astype('uint8'),t.affine),p/(stem+'_T1.nii.gz'));r[stem]={'original_voxels':int(m.sum())}
  # Explicit 3x3x3 one-voxel dilation on 1 mm T1 grid for endpoint ROIs.
  if name!='CerebellarCortex':
   d=binary_dilation(m,structure=np.ones((3,3,3),bool),iterations=1);nib.save(nib.Nifti1Image(d.astype('uint8'),t.affine),p/(stem+'_dil1mm_T1.nii.gz'));r[stem]['dilated_voxels']=int(d.sum());masks.append((stem,m))
fig,ax=plt.subplots(4,3,figsize=(11,12)); tc=nib.as_closest_canonical(t);a=tc.get_fdata();vmax=np.percentile(a[a>0],99)
for row,(name,m) in enumerate(masks):
 ni=nib.as_closest_canonical(nib.Nifti1Image(m.astype('uint8'),t.affine));d=ni.get_fdata();assert d.sum()>0;center=np.round(np.argwhere(d).mean(axis=0)).astype(int)
 for c in range(3):
  ax[row,c].imshow(np.take(a,center[c],axis=c).T,origin='lower',cmap='gray',vmin=0,vmax=vmax);ax[row,c].contour(np.take(d,center[c],axis=c).T,levels=[.5],colors=['red']);ax[row,c].set_title(name);ax[row,c].axis('off')
fig.tight_layout();fig.savefig(base/'qc/individual_ROIs_T1.png',dpi=130)
(p/'individual_roi_summary.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
