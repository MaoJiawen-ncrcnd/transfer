from pathlib import Path
import json
import numpy as np
import nibabel as nib
from nibabel.processing import resample_to_output
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Line3DCollection
w=Path(__file__).parent/'output';out=w/'tracts';fig=plt.figure(figsize=(12,7));alltracks=[];checks={}
for i,(stem,title,color) in enumerate([('LeftDentate_to_RightMorelVLp','Left dentate - Right Morel VLp','tab:orange'),('RightDentate_to_LeftMorelVLp','Right dentate - Left Morel VLp','tab:blue')]):
 a=list(nib.streamlines.load(str(out/(stem+'_cleaned.tck'))).streamlines);b=list(nib.streamlines.load(str(out/(stem+'_cleaned.trk'))).streamlines)
 assert len(a)==len(b)>0
 error=max(float(np.max(abs(x-y))) for x,y in zip(a,b));assert error<.001
 lengths=[float(np.linalg.norm(np.diff(x,axis=0),axis=1).sum()) for x in a];checks[stem]={'cleaned_count':len(a),'tck_trk_max_coordinate_difference_mm':error,'mean_length_mm':float(np.mean(lengths)),'median_length_mm':float(np.median(lengths))}
 ax=fig.add_subplot(1,2,i+1,projection='3d');sample=a[::max(1,len(a)//250)];pts=np.vstack(sample);ax.add_collection3d(Line3DCollection(sample,colors=color,linewidths=.6,alpha=.4));lo=pts.min(0)-4;hi=pts.max(0)+4;ax.set_xlim(lo[0],hi[0]);ax.set_ylim(lo[1],hi[1]);ax.set_zlim(lo[2],hi[2]);ax.set_box_aspect(hi-lo);ax.set(xlabel='R (mm)',ylabel='A (mm)',zlabel='S (mm)');ax.set_title(title+'\n'+str(len(a))+' statistically cleaned streamlines',fontsize=11,pad=8);ax.view_init(elev=15,azim=-85);alltracks.append((color,a))
fig.subplots_adjust(left=.02,right=.98,bottom=.09,top=.89,wspace=.05);fig.savefig(out/'cleaned_tract_overview.png',dpi=160,bbox_inches='tight')
ref=resample_to_output(nib.load(w/'preproc/corrected_b0.nii.gz'),voxel_sizes=(2,2,2),order=1);af=ref.affine;d=ref.get_fdata();pts=np.vstack([np.vstack(s) for _,s in alltracks]);lo,hi=np.percentile(pts[:,2],[1,99]);fig,axs=plt.subplots(2,4,figsize=(14,8))
for ax,z in zip(axs.flat,np.linspace(lo,hi,8)):
 iz=int(np.clip(round((z-af[2,3])/2),0,d.shape[2]-1));z=af[2,3]+iz*2
 ax.imshow(d[:,:,iz].T,origin='lower',cmap='gray',vmin=0,vmax=np.percentile(d[d>0],99),extent=[af[0,3],af[0,3]+2*(d.shape[0]-1),af[1,3],af[1,3]+2*(d.shape[1]-1)])
 for color,sls in alltracks:
  x=np.vstack(sls[::max(1,len(sls)//400)]);x=x[abs(x[:,2]-z)<1.5];ax.scatter(x[:,0],x[:,1],s=.6,c=color,alpha=.4)
 ax.set_title('z = '+str(round(z,1))+' mm (scanner RAS)',fontsize=10);ax.axis('off')
fig.suptitle('Cleaned streamline vertices within +/-1.5 mm of b0 slices\nOrange: left DN-right VLp | Blue: right DN-left VLp',fontsize=12);fig.tight_layout(rect=[0,0,1,.92]);fig.savefig(out/'cleaned_anatomical_slices.png',dpi=150)
(out/'export_validation.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks))
