#!/usr/bin/env bash
set -euo pipefail
export FSLOUTPUTTYPE=NIFTI_GZ
export OMP_NUM_THREADS=4
export ITK_GLOBAL_DEFAULT_NUMBER_OF_THREADS=4
cd "$W/output/preproc"
exec > >(tee -a stage2.log) 2>&1
date -Is
cp "$W/index.txt" index.txt
eddy_cpu --imain=dwi_denoised --mask=b0_brain_mask --acqp=acqparams.txt --index=index.txt --bvecs=bvecs --bvals=bvals --topup=topup --out=dwi_eddy --repol --data_is_shelled --verbose
date -Is
echo EDDY_COMPLETE
