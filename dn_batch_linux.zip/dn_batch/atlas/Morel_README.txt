VOXELIZED VERSION of the MOREL ATLAS of the HUMAN THALAMUS
*************************************************************
is a digital image file that represents the 3D anatomy of the thalamus, transformed to the Montreal Neurological Institute 152 anatomical reference space.

Details are found in the following publication:

Andras Jakab, Remi Blanc, Ervin Berenyi and Gábor Székely: Generation of individualized thalamus target maps by using statistical shape models and thalamocortical tractography. AJNR, 33(11) pp. 2110-2116, 2012

and:

Axel Krauth, Remi Blanc, Alejandra Poveda, Daniel Jeanmonod, Anne Morel and Gábor Székely: A mean three-dimensional atlas of the human thalamus: Generation from multiple histological data. Neuroimage, 49(3) pp. 2053-2062, 2010

Any report or publication of results obtained by the use of the Voxelized Version of the Morel Atlas must acknowledge by citing both publications above.

COPYRIGHT NOTICE
******************
This dataset is released under the Creative Commons Attribution Non Commercial Share Alike 4.0 International License.

Each copy of the Voxelized Version of the Morel Atlas must reproduce the copyright notice:
“© University of Zurich and ETH Zurich, Andras Jakab, Rémi Blanc and Gábor Székely”

DISCLAIMER
************
The Atlas is provided “as is”. All liabilities are disclaimed. No warranties of any kind are made. Disclaimed warranties include for example:
i. warranty of satisfactory quality and fitness for a particular purpose
ii. warranty of accuracy of results, of the quality and performance of the Atlas
iii. warranty of noninfringement of the intellectual property rights of third parties.

COPYRIGHT NOTICE to the "MNI 152 TEMPLATE"
**********************************
Copyright (C) 1993–2009 Louis Collins, McConnell Brain Imaging Centre, Montreal Neurological Institute, McGill University. Permission to use, copy, modify, and distribute the "MNI 152 TEMPLATE" and its documentation for any purpose and without fee is hereby granted, provided that the above copyright notice appear in all copies. The authors and McGill University make no representations about the suitability of this software for any purpose. It is provided “as is” without express or implied warranty. The authors are not responsible for any data loss, equipment damage, property loss, or injury to subjects or patients resulting from the use or misuse of this software package.

Please cite this publicaiton when using the template image:
G. Grabner, A. L. Janke, M. M. Budge, D. Smith, J. Pruessner, and D. L. Collins, “Symmetric atlasing and model based segmentation: an application to the hippocampus in older adults”, Med Image Comput Comput Assist Interv Int Conf Med Image Comput Comput Assist Interv, vol. 9, pp. 58–66, 2006. https://dx.doi.org/10.1007/11866763_8

FILES
*******

Each atlas file defines a NIFTY GZIPPED image of a particular thalamic sub-structure.

The Atlas is composed of the following files, stored separately for the left and right hemispheres, and in 1mm and 0.5mm isotropic voxel dimensions (166 .nii.gz files):

AD.nii.gz
AM.nii.gz
AV.nii.gz
CeM.nii.gz
CL.nii.gz
CM.nii.gz
global.nii.gz
Hb.nii.gz
LD.nii.gz
LGN.nii.gz
LGNmc.nii.gz
LGNpc.nii.gz
Li.nii.gz
LP.nii.gz
MAX_VOLUME.nii.gz
MDmc.nii.gz
MDpc.nii.gz
MGN.nii.gz
mtt.nii.gz
MV.nii.gz
Pf.nii.gz
Po.nii.gz
PuA.nii.gz
PuI.nii.gz
PuL.nii.gz
PuM.nii.gz
Pv.nii.gz
RN.nii.gz
SG.nii.gz
sPf.nii.gz
STh.nii.gz
thalamus_body.nii.gz
VAmc.nii.gz
VApc.nii.gz
VLa.nii.gz
VLp.nii.gz
VLpd.nii.gz
VLpv.nii.gz
VM.nii.gz
VPI.nii.gz
VPLa.nii.gz
VPLp.nii.gz
VPM.nii.gz

MNI152_T1_0.5mm.nii.gz
MNI152_T1_1mm.nii.gz


