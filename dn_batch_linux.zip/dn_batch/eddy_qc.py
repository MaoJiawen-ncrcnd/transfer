from pathlib import Path
import json
import numpy as np
import nibabel as nib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).parent/'output'/'preproc'; out=p.parent/'qc'
im=nib.load(p/'dwi_eddy.nii.gz');a=im.get_fdata(dtype=np.float32);b=np.loadtxt(p/'bvals');v=np.loadtxt(p/'dwi_eddy.eddy_rotated_bvecs')
report={'shape':list(a.shape),'finite':bool(np.isfinite(a).all()),'rotated_bvec_shape':list(v.shape)}
assert a.shape[-1]==len(b)==v.shape[1] and report['finite']
for suffix in ['eddy_movement_rms','eddy_restricted_movement_rms','eddy_outlier_map']:
 f=p/('dwi_eddy.'+suffix)
 if f.exists():
  try:x=np.loadtxt(f)
  except ValueError:x=np.loadtxt(f,skiprows=1)
  report[suffix]={'shape':list(x.shape),'mean':np.mean(x,axis=0).tolist() if 'rms' in suffix else float(x.mean()),'max':float(x.max())}
  if suffix=='eddy_outlier_map':report[suffix]['fraction']=float(np.mean(x>0));report[suffix]['worst_volume_fraction']=float(np.max(np.mean(x>0,axis=1)))
(out/'eddy_qc_summary.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
fig,ax=plt.subplots(3,5,figsize=(13,8))
for r,s in enumerate([0,1000,2000]):
 mean=a[...,abs(b-s)<50].mean(axis=3); ni=nib.as_closest_canonical(nib.Nifti1Image(mean,im.affine));d=ni.get_fdata();vmax=np.percentile(d[d>0],99)
 for c,frac in enumerate([.15,.3,.45,.6,.75]):
  z=round(frac*(d.shape[2]-1));ax[r,c].imshow(d[:,:,z].T,origin='lower',cmap='gray',vmin=0,vmax=vmax);ax[r,c].set_title('Corrected b='+str(s));ax[r,c].axis('off')
fig.tight_layout();fig.savefig(out/'eddy_corrected_montage.png',dpi=130)
