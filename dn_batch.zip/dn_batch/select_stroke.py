import csv
import re
import sys
from pathlib import Path

root = Path(sys.argv[1])
with (root / "participants.tsv").open(encoding="utf-8-sig") as source:
    rows = csv.DictReader(source, delimiter="\t")
    required = {"ID", "group", "lesion_side"}
    if not required.issubset(rows.fieldnames or []):
        sys.exit("Check participants.tsv header: expected ID, group, lesion_side")
    subjects = {}
    for row in rows:
        match = re.fullmatch(r"TMS-?(\d+)", row["ID"].strip(), re.I)
        if not match:
            sys.exit("Invalid participant ID: " + row["ID"])
        key = "sub-TMS" + match[1] + "ses01"
        if key in subjects:
            sys.exit("Duplicate participant: " + key)
        subjects[key] = row
selected = []
for folder in sorted(root.glob("sub-TMS*ses01")):
    if not folder.is_dir():
        continue
    if folder.name not in subjects:
        sys.exit("Missing participant record: " + folder.name)
    row = subjects[folder.name]
    if row["group"].strip().lower() == "stroke":
        selected.append((folder, row["lesion_side"].strip()))
if not selected:
    sys.exit("No stroke ses01 folders matched")
for folder, side in selected:
    print(f"{folder}\t{side}")
