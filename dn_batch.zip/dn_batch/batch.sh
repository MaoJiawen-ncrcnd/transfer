#!/usr/bin/env bash
set -eu
pkg=$(cd "$(dirname "$0")" && pwd)
root=${DATA_ROOT:-/data02/linzhenzong/TMS-MRI/Data_flip}
out=${OUT_ROOT:-/data01/home/maojiawen/MaoJiawenAnalysis/DTI/results}
export MODE=${1:-check} A="$pkg/atlas" M="$pkg/atlas/MNI152_T1_1mm.nii.gz"
[[ "$MODE" == check || "$MODE" == run ]]
: "${FSLDIR:?Load FSL first}"
for cmd in python3 dwidenoise tckgen eddy_cpu topup fast bet antsRegistrationSyN.sh N4BiasFieldCorrection; do command -v "$cmd" >/dev/null || { echo "Missing $cmd"; exit 1; }; done
python3 -c 'import scipy,numpy,nibabel,matplotlib'
one(){
 export S="$1" ID="${1##*/}" ANAT="$1/anat"
 raw="$ANAT/${ID}_T1w.nii.gz"
 echo "$ID group=stroke lesion_side_as_recorded=$side"
 test -r "$raw"
 python3 "$pkg/check.py"
 if [[ "$MODE" == check ]]; then echo "$ID inputs OK"; return; fi
 cp "$pkg/"*.py "$W/"
 cp "$A/"*_MNI.nii.gz "$W/output/roi/"
 export T="$W/T1.nii.gz" GM="$W/gm_pve_1.nii.gz" FSLOUTPUTTYPE=NIFTI_GZ
 mrgrid "$raw" regrid "$T" -voxel 1
 bet "$T" "$W/brain" -R
 fast -o "$W/gm" "$W/brain.nii.gz"
 for step in preprocess_stage1 preprocess_stage2 model_stage3 register_morel register_cerebellum; do bash "$pkg/$step.sh"; done
 python3 "$W/finalize_rois.py"
 bash "$pkg/map_rois_to_dwi.sh"
 bash "$pkg/track_dentatothalamic.sh"
 for step in summarize_tracks clean_tracks final_qc; do python3 "$W/$step.py"; done
 touch "$W/COMPLETE"
}
shopt -s nullglob
records=$(python3 "$pkg/select_stroke.py" "$root")
mapfile -t subs <<< "$records"
(( ${#subs[@]} )) || { echo "No ses01 directories in $root"; exit 1; }
status=0
for record in "${subs[@]}"; do
 IFS=$'\t' read -r sub side <<< "$record"
 [[ -d "$sub" && ( -z "${2:-}" || "${sub##*/}" == "$2" ) ]] || continue
 export W="$out/${sub##*/}"
 if [[ "$MODE" == run ]]; then
  [[ -f "$W/COMPLETE" ]] && continue
  mkdir -p "$out"
  mkdir "$W" || { echo "Existing incomplete run: $W"; status=1; continue; }
  mkdir -p "$W/output/"{roi,qc,preproc,tracts}
 fi
 set +e
 (set -e; one "$sub") > >(if [[ "$MODE" == run ]]; then tee "$W/run.log"; else cat; fi) 2>&1
 rc=$?
 set -e
 if (( rc )); then echo "FAILED ${sub##*/}"; status=1; fi
done
exit "$status"
